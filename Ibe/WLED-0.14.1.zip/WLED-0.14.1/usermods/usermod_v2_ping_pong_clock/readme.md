# Ping Pong LED Clock

Contains a modification to use WLED in combination with the Ping Pong Ball LED Clock as built in [Instructables](https://www.instructables.com/Ping-Pong-Ball-LED-Clock/).

## Installation 

To install this Usermod, you instruct PlatformIO to compile the Project with the USERMOD_PING_PONG_CLOCK flag.
WLED then automatically provides you with various settings on the Usermod Page.

Note: Depending on the size of your clock, you may have to update the led indices for the individual numbers and the base indices.
